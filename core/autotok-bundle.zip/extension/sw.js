// Service worker: coordinator only. All long work (upload, editor, waiting) runs in the Studio tab's
// content script, so a stopped/restarted SW loses nothing: durable state lives in chrome.storage.local
// ('activeJob'), every handler re-reads it, and the worker is re-woken by alarms / content messages.
//
// Idempotency rules (X1 in miniature):
//  - activeJob is written BEFORE the window is opened; a job id that already has an activeJob (or was the
//    last finished one) is never started again -> no second window after a restart.
//  - 'authorized' is persisted BEFORE the content script is allowed to click Post, and only one 'authorize'
//    per job is ever granted (here and on the dev server). A reloaded tab or restarted SW after that point
//    finishes the job as 'uncertain', never re-clicks.
'use strict';

const STUDIO_URL = 'https://www.tiktok.com/tiktokstudio/upload';
const PROTOCOL = 1;
const EXT_VERSION = (typeof chrome.runtime.getManifest === 'function' && chrome.runtime.getManifest().version) || '0.0.0';
const DEFAULTS = { server: 'http://127.0.0.1:8765', token: '', clientId: null, windowStrategy: 'minimized', keepOpen: false, polling: true };
const HELLO_EVERY_MS = 55 * 1000;
const HEARTBEAT_EVERY_MS = 40 * 1000;
const NEED_RELOAD_TEXT = 'Cần tải lại tiện ích (chrome://extensions → ⟳)';
const JOB_DEADLINE_MS = 40 * 60 * 1000;   // whole job
const STALL_MS = 5 * 60 * 1000;           // no progress message from the tab (minimized tabs are throttled)
const CHUNK = 1024 * 1024;
const MAX_LOG = 40;
const CLOSE_GRACE_MS = 10000;

// ---------- storage helpers (serialized so concurrent handlers cannot interleave read-modify-write) ----------
let chain = Promise.resolve();
const locked = (fn) => { const r = chain.then(fn); chain = r.catch(() => {}); return r; };

const getSettings = async () => Object.assign({}, DEFAULTS, (await chrome.storage.local.get('settings')).settings || {});
const getActive = async () => (await chrome.storage.local.get('activeJob')).activeJob || null;

function patchActive(patch, onlyId) {
  return locked(async () => {
    const a = await getActive();
    if (!a || (onlyId && a.id !== onlyId)) return null;
    const n = Object.assign({}, a, patch);
    await chrome.storage.local.set({ activeJob: n });
    return n;
  });
}

function log(msg, level) {
  const line = new Date().toISOString().slice(11, 23) + ' ' + (level ? level + ' ' : '') + msg;
  console.log('[autotok]', line);
  return locked(async () => {
    const { log: l = [] } = await chrome.storage.local.get('log');
    l.push(line);
    await chrome.storage.local.set({ log: l.slice(-MAX_LOG) });
  });
}

// ---------- backend API (PROTOCOL.md v1) ----------
const getConn = async () => (await chrome.storage.local.get('conn')).conn || { state: 'unpaired' };
const setConn = (patch) => locked(async () => { const c = Object.assign({}, await getConn(), patch, { at: Date.now() }); await chrome.storage.local.set({ conn: c }); return c; });

// Errors carry .status (HTTP), .code (protocol `error`) and .body. 401 / 409 states are recorded for the popup + poll loop.
async function api(path, { method = 'GET', body, timeoutMs = 15000, raw = false, headers = {}, auth = true } = {}) {
  const s = await getSettings();
  if (auth && !s.token) throw new Error('chưa ghép nối');
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const h = Object.assign({ 'X-Autotok-Protocol': String(PROTOCOL) }, auth ? { Authorization: 'Bearer ' + s.token } : {},
      method === 'POST' ? { 'X-Requested-With': 'autotok' } : {}, body ? { 'Content-Type': 'application/json; charset=utf-8' } : {}, headers);
    const r = await fetch(s.server + path, { method, signal: ctl.signal, headers: h, body: body ? JSON.stringify(body) : undefined });
    if (raw) return r;
    if (r.status === 204) return null;
    if (!r.ok) {
      let b = null; try { b = await r.json(); } catch (_) { /* non-JSON error body */ }
      const err = new Error((b && b.message) || `${method} ${path} -> HTTP ${r.status}`);
      err.status = r.status; err.code = b && b.error; err.body = b;
      await noteApiError(err);
      throw err;
    }
    return await r.json();
  } finally { clearTimeout(timer); }
}

async function noteApiError(e) {
  if (e.status === 401) await setConn({ state: 'unauthorized', message: 'Cần ghép nối lại' });
  else if (e.status === 409 && e.code === 'need_reload') await setConn({ state: 'need_reload', needReload: true, message: NEED_RELOAD_TEXT });
  else if (e.status === 409 && (e.code === 'identity_conflict' || e.code === 'no_identity')) await setConn({ state: e.code === 'identity_conflict' ? 'conflict' : 'no_identity', message: e.message });
}

// What the backend wants for a result: snake_case, not_sent, submitted schedule, sanitized response.
function toWire(a, r) {
  const w = { id: a.id, nonce: a.nonce, claim_token: a.claim_token, outcome: r.outcome, definite: r.definite === true, not_sent: r.notSent === true,
    reason: r.reason, detail: r.detail, http: r.http, status_code: r.status_code, status_msg: r.status_msg, item_id: r.item_id,
    creation_id: r.creation_id, video_id: r.video_id, schedule_time: r.schedule_time == null ? null : r.schedule_time, response: r.response, elapsed_ms: r.elapsed_ms };
  for (const k of Object.keys(w)) if (w[k] === undefined) delete w[k];
  return w;
}

// Logged-in TikTok account of this Chrome profile: the passport self endpoint only (data.username + data.user_id_str).
async function passportIdentity() {
  try {
    const r = await fetch('https://www.tiktok.com/passport/web/account/info/?aid=1988', { credentials: 'include' });
    const d = ((await r.json()) || {}).data || {};
    const username = typeof d.username === 'string' ? d.username.replace(/^@/, '').trim().toLowerCase() : '';
    const userId = typeof d.user_id_str === 'string' ? d.user_id_str.trim() : '';
    return username && userId ? { username, user_id: userId } : null;
  } catch (e) { console.warn('[autotok] passport', e); return null; }
}

// hello: protocol + version + identity. Answers need_reload / conflict / bound account.
async function sendHello() {
  const identity = await passportIdentity();
  const r = await api('/api/ext/hello', { method: 'POST', body: { protocol: PROTOCOL, ext_version: EXT_VERSION, identity } });
  const state = r.need_reload ? 'need_reload' : r.conflict ? 'conflict' : !identity ? 'no_identity' : 'ok';
  await setConn({ state, needReload: !!r.need_reload, message: r.need_reload ? (r.message || NEED_RELOAD_TEXT) : (r.message || ''),
    identity, bound: r.account || null, helloAt: Date.now(), error: '' });
  if (identity) await chrome.storage.local.set({ account: identity.username });
  return r;
}
async function helloIfDue(force) {
  const c = await getConn();
  if (!force && c.helloAt && Date.now() - c.helloAt < HELLO_EVERY_MS) return;
  try { await sendHello(); } catch (e) { console.warn('[autotok] hello', e); await setConn({ helloAt: Date.now() - HELLO_EVERY_MS + 10000, error: e.message }); }
}

function b64(buf) {
  const u = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
}

// ---------- window / tab ----------
async function openJobWindow(job) {
  const existing = await findJobTab({ id: job.id, windowId: null, strategy: 'tab' });
  if (existing) { await log(`đã có tab ${existing.id} cho job ${job.id}, không mở thêm`, 'WARN'); await patchActive({ tabId: existing.id, windowId: existing.windowId }, job.id); return; }
  const s = await getSettings();
  const url = STUDIO_URL + '#autotok=' + encodeURIComponent(job.id);
  let tab, windowId;
  if (s.windowStrategy === 'tab') {
    tab = await chrome.tabs.create({ url, active: false });
    windowId = tab.windowId;
  } else if (s.windowStrategy === 'unfocused') {
    const w = await chrome.windows.create({ url, focused: false, state: 'normal', width: 1100, height: 800, left: 40, top: 40 });
    tab = w.tabs[0]; windowId = w.id;
  } else {
    const w = await chrome.windows.create({ url, state: 'minimized', focused: false });
    tab = w.tabs[0]; windowId = w.id;
  }
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) { await log('autoDiscardable: ' + e.message, 'WARN'); }
  await patchActive({ tabId: tab.id, windowId, phase: 'opened', strategy: s.windowStrategy, lastBeat: Date.now() });
  await log(`mở tab ${tab.id} (cửa sổ ${windowId}, kiểu ${s.windowStrategy}) cho job ${job.id}`);
}

async function closeJobWindow(a) {
  const s = await getSettings();
  if (s.keepOpen || !a) return;
  try {
    if (a.strategy === 'tab' && a.tabId != null) await chrome.tabs.remove(a.tabId);
    else if (a.windowId != null) await chrome.windows.remove(a.windowId);
  } catch (e) { await log('đóng cửa sổ: ' + e.message, 'WARN'); }
}

// ---------- job lifecycle ----------
async function startJob(job, local) {
  if (!['selftest', 'intercept', 'post', 'selfcheck'].includes(job.mode)) {
    await log(`từ chối job ${job.id}: chế độ "${job.mode}" không hỗ trợ`, 'WARN');
    if (!local) await api('/api/ext/result', { method: 'POST', body: { id: job.id, nonce: job.nonce, claim_token: job.claim_token, outcome: 'failed', definite: true, not_sent: true, reason: 'mode-unsupported' } }).catch((e) => log('gửi từ chối lỗi: ' + e.message, 'WARN'));
    return;
  }
  const claimed = await locked(async () => {
    const { activeJob, lastDoneId } = await chrome.storage.local.get(['activeJob', 'lastDoneId']);
    if (activeJob) return { ok: false, resume: activeJob.id === job.id };
    if (lastDoneId === job.id) return { ok: false, resume: false };
    await chrome.storage.local.set({
      activeJob: {
        id: job.id, nonce: job.nonce, claim_token: job.claim_token, mode: job.mode, job, local: !!local, phase: 'opening', openingAt: Date.now(),
        startedAt: Date.now(), lastBeat: Date.now(), tabId: null, windowId: null, authorized: false, finished: false,
      },
    });
    return { ok: true };
  });
  if (!claimed.ok) {
    if (!claimed.resume) await log(`bỏ qua job ${job.id}: đang có job khác hoặc đã xong`);
    return;
  }
  await log(`nhận job ${job.id} (${job.mode})`);
  try { await openJobWindow(job); } catch (e) {
    await finishJob(job.id, { outcome: 'failed', definite: true, reason: 'open-window-failed', detail: e.message });
  }
}

async function finishJob(id, result) {
  // Re-read `authorized` under the lock: once a post was authorized, a plain "failed" can no longer be trusted as
  // definite (the click may have happened) unless the page code explicitly said nothing was sent.
  let a = null;
  let final = result;
  await locked(async () => {
    const cur = await getActive();
    if (!cur || cur.id !== id) return;
    if (cur.authorized && result && result.outcome === 'failed' && result.notSent !== true) {
      final = Object.assign({}, result, { outcome: 'uncertain', definite: false, downgraded_from: 'failed' });
    }
    a = Object.assign({}, cur, { finished: true, result: final, finishedAt: Date.now() });
    await chrome.storage.local.set({ activeJob: a });
  });
  if (!a) return { ok: false, reason: 'no-active-job' };
  const full = Object.assign({ id, nonce: a.nonce, elapsed_ms: Date.now() - a.startedAt, authorized: a.authorized }, final);
  await log(`kết quả job ${id}: ${full.outcome}${full.reason ? ' (' + full.reason + ')' : ''}`);
  await chrome.storage.local.set({ lastResult: full });
  if (full.identity && (full.identity.value || full.identity.username)) await chrome.storage.local.set({ account: full.identity.value || full.identity.username });
  await closeJobWindow(a);
  if (!a.local && !(await deliverResult(a, full))) return { ok: true, pending: true };
  await locked(async () => { await chrome.storage.local.set({ lastDoneId: id }); await chrome.storage.local.remove('activeJob'); });
  return { ok: true };
}

const isGone = (e) => e && (e.status === 404 || e.status === 403);

// Drop a job the server no longer knows (404/403): keep the result for diagnosis, never retry it.
async function dropOrphan(a, result, why) {
  await log(`máy chủ không còn việc này, bỏ kết quả (${why})`, 'WARN');
  if (result) await chrome.storage.local.set({ lastOrphanResult: { id: a.id, result, at: Date.now() } });
  await closeJobWindow(a);
  await locked(async () => { await chrome.storage.local.set({ lastDoneId: a.id }); await chrome.storage.local.remove('activeJob'); });
}

// true = delivered or dropped (job cleared); false = transient failure, retry later with capped backoff.
async function deliverResult(a, full) {
  try {
    await api('/api/ext/result', { method: 'POST', body: toWire(a, full), timeoutMs: 20000 });
    return true;
  } catch (e) {
    if (isGone(e)) { await dropOrphan(a, full, e.message); return false; }
    const tries = (a.resultTries || 0) + 1;
    const delay = Math.min(2000 * 2 ** tries, 30000);
    await patchActive({ resultTries: tries, nextResultTry: Date.now() + delay }, a.id);
    await log(`gửi kết quả lỗi (${e.message}), thử lại sau ${delay / 1000}s`, 'WARN');
    return false;
  }
}

async function findJobTab(a) {
  const tabs = await chrome.tabs.query({ url: 'https://www.tiktok.com/*' });
  return tabs.find((x) => (x.url || '').includes('#autotok=' + encodeURIComponent(a.id))) || tabs.find((x) => x.windowId === a.windowId && a.strategy !== 'tab') || null;
}

// Revoked by the backend (deadline missed / cancelled in the app): never authorize, close the tab, forget the job.
async function revokeLocal(a, why) {
  await log(`backend đã thu hồi việc ${a.id} (${why})`, 'WARN');
  await closeJobWindow(a);
  await locked(async () => { await chrome.storage.local.set({ lastDoneId: a.id }); await chrome.storage.local.remove('activeJob'); });
}

// POST /api/ext/progress. -> {ok, revoked?}. Network errors are logged and reported as ok:true (a later heartbeat retries).
async function sendProgress(a, p) {
  try {
    const r = await api('/api/ext/progress', { method: 'POST', timeoutMs: 10000, body: Object.assign({ id: a.id, nonce: a.nonce, claim_token: a.claim_token }, p) });
    if (r && r.ok === false && (r.cancelled || r.state === 'revoked')) { await revokeLocal(a, 'progress'); return { ok: false, revoked: true }; }
    return { ok: true };
  } catch (e) {
    if (isGone(e)) { await dropOrphan(a, null, 'progress ' + e.message); return { ok: false, revoked: true }; }
    await log('gửi tiến độ lỗi: ' + e.message, 'WARN');
    return { ok: true, unsent: true };
  }
}

// Called on every tick and every wake-up: reconcile durable state with reality.
async function recover() {
  const a = await getActive();
  if (!a) return false;
  if (a.finished) { // result not delivered yet
    if (!a.local && Date.now() >= (a.nextResultTry || 0)) {
      const full = Object.assign({ id: a.id, nonce: a.nonce, authorized: a.authorized }, a.result);
      if (await deliverResult(a, full)) await locked(async () => { await chrome.storage.local.set({ lastDoneId: a.id }); await chrome.storage.local.remove('activeJob'); });
    } else if (a.local) {
      await locked(async () => { await chrome.storage.local.set({ lastDoneId: a.id }); await chrome.storage.local.remove('activeJob'); });
    }
    return true;
  }
  const now = Date.now();
  if (a.tabId == null) {
    const tabs = await chrome.tabs.query({ url: 'https://www.tiktok.com/tiktokstudio/*' });
    const t = tabs.find((x) => (x.url || '').includes('#autotok=' + encodeURIComponent(a.id)));
    if (t) { await patchActive({ tabId: t.id, windowId: t.windowId, phase: 'opened' }, a.id); await log('khôi phục tab ' + t.id); }
    else if (now - a.openingAt > 20000) { // window creation never finished and no tab exists: nothing was sent
      await openJobWindow(a.job);
    }
    return true;
  }
  let gone = false;
  try { await chrome.tabs.get(a.tabId); if (a.missingSince) await patchActive({ missingSince: null }, a.id); } catch (_) { gone = true; }
  if (gone) { // the tab id may have changed (prerender/discard): look it up by URL hash / window first
    const t = await findJobTab(a);
    if (t) { await log(`tìm lại tab theo URL/cửa sổ: ${a.tabId} -> ${t.id}`, 'WARN'); await patchActive({ tabId: t.id, windowId: t.windowId, missingSince: null }, a.id); return true; }
    if (!a.missingSince) { await patchActive({ missingSince: now }, a.id); return true; }
    if (now - a.missingSince < CLOSE_GRACE_MS) return true;
    await finishJob(a.id, a.authorized
      ? { outcome: 'uncertain', reason: 'tab-closed-after-authorization' }
      : { outcome: 'failed', definite: true, reason: 'tab-closed-before-authorization', detail: 'missing for ' + (now - a.missingSince) + ' ms, no tab with the job hash in window ' + a.windowId });
    return true;
  }
  if (!a.local && !a.authorized && now - (a.hbAt || 0) > HEARTBEAT_EVERY_MS) { // backend deadline: a heartbeat at least every 60 s
    await patchActive({ hbAt: now }, a.id);
    const r = await sendProgress(a, { phase: a.phase, msg: 'heartbeat' });
    if (r && r.revoked) return true;
  }
  if (now - a.startedAt > JOB_DEADLINE_MS || now - a.lastBeat > STALL_MS) {
    const why = now - a.startedAt > JOB_DEADLINE_MS ? 'job-deadline' : 'tab-stalled';
    await finishJob(a.id, a.authorized ? { outcome: 'uncertain', reason: why + '-after-authorization' }
      : { outcome: 'failed', definite: true, reason: why });
  }
  return true;
}

// ---------- polling ----------
let polling = false;
let lastPollState = '';
const setPoll = async (state) => { if (state !== lastPollState) { lastPollState = state; await chrome.storage.local.set({ poll: { at: Date.now(), state } }); } };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function pollLoop() {
  if (polling) return;
  polling = true;
  try {
    for (;;) {
      try {
        const s = await getSettings();
        if (!s.polling || !s.token) { await setPoll(s.token ? 'tắt' : 'chưa ghép nối'); return; }
        await helloIfDue();
        if (await recover()) { await wait(4000); continue; }   // an active / undelivered job: no new claims
        const c = await getConn();
        if (c.state === 'unauthorized') { await setPoll('cần ghép nối lại'); return; }
        if (c.needReload) { await setPoll('cần tải lại tiện ích'); await wait(10000); continue; }   // never claim while out of protocol range
        if (c.state === 'conflict' || c.state === 'no_identity') { await setPoll(c.state === 'conflict' ? 'trùng tài khoản' : 'chưa đăng nhập TikTok'); await wait(10000); continue; }
        await setPoll('đang chờ job');
        const job = await api('/api/ext/next?wait=20', { timeoutMs: 30000 });
        if (job) await startJob(job, false);
      } catch (e) {
        // includes "No SW" when Chrome tears the worker down mid-await: log, back off, alarm restarts us
        console.warn('[autotok] pollLoop', e);
        try { await setPoll('lỗi: ' + e.message); } catch (_) { return; }
        await wait(5000);
      }
    }
  } finally { polling = false; }
}

// ---------- content-script messages ----------
async function jobFor(sender, msg) {
  const a = await getActive();
  if (!a || a.finished || !sender.tab || a.tabId !== sender.tab.id) return null;
  if (msg.nonce && msg.nonce !== a.nonce) return null;
  return a;
}

const handlers = {
  async hello(msg, sender) {
    let a = await getActive();
    const t = sender.tab;
    if (a && !a.finished && t && !a.authorized && a.tabId !== t.id) {
      const byHash = (t.url || '').includes('#autotok=' + encodeURIComponent(a.id));
      const byWindow = a.windowId != null && t.windowId === a.windowId && a.strategy !== 'tab';
      if (a.tabId == null ? byHash : (byHash || byWindow)) {
        await log(`hello từ tab ${t.id} (${byHash ? 'hash' : 'cùng cửa sổ'}), nhận làm tab của job (trước: ${a.tabId})`, 'WARN');
        a = await patchActive({ tabId: t.id, windowId: t.windowId, phase: 'opened', missingSince: null }, a.id);
      }
    }
    a = a && !a.finished && t && a.tabId === t.id ? a : null;
    if (!a) return { role: 'none' };
    if (a.authorized) { // tab reloaded after the Post click was authorized: never redo
      await finishJob(a.id, { outcome: 'uncertain', reason: 'tab-reloaded-after-authorization' });
      return { role: 'none' };
    }
    if (!a.local) { // resume only while the server still considers the job active
      let st = null;
      try { st = await api('/api/ext/job_state?id=' + encodeURIComponent(a.id), { timeoutMs: 5000 }); } catch (e) { await log('job_state: ' + e.message, 'WARN'); }
      if (!st || !['claimed', 'uploading', 'ready'].includes(st.state) || st.authorized) {
        await log(`không tiếp tục job ${a.id}: server=${st && st.state}${st && st.authorized ? ' đã cấp quyền' : ''}`, 'WARN');
        await chrome.storage.local.set({ lastDoneId: a.id }); await chrome.storage.local.remove('activeJob');
        return { role: 'none' };
      }
    }
    await patchActive({ phase: 'hello', lastBeat: Date.now() }, a.id);
    return { role: a.mode === 'selfcheck' ? 'selfcheck' : 'job', job: a.job, nonce: a.nonce };
  },

  async ready(msg, sender) { // content script injected: log + tell the dev server immediately
    const a = await getActive();
    const mine = !!(a && !a.finished && sender.tab && (a.tabId === sender.tab.id || (sender.tab.url || '').includes('#autotok=' + encodeURIComponent(a.id))));
    await log(`content script ${msg.stage} tab=${sender.tab && sender.tab.id} ${msg.where} job=${mine ? a.id : '-'}`);
    if (mine && !a.local) await sendProgress(a, { phase: 'content-ready', msg: msg.stage + ' ' + msg.where, extra: { tabId: sender.tab.id, state: msg.state } });
    return { ok: true };
  },

  async progress(msg, sender) {
    const a = await jobFor(sender, msg);
    if (!a) return { ok: false };
    await patchActive({ phase: msg.phase, pct: msg.pct == null ? null : msg.pct, lastBeat: Date.now() }, a.id);
    await log(`[${msg.phase}] ${msg.msg || ''}${msg.pct != null ? ' ' + msg.pct + '%' : ''}`);
    if (!a.local) {
      await patchActive({ hbAt: Date.now() }, a.id);
      const r = await sendProgress(a, { phase: msg.phase, msg: msg.msg, pct: msg.pct, extra: msg.extra });
      if (r.revoked) return { ok: false, revoked: true };
    }
    return { ok: true };
  },

  async videoMeta(msg, sender) {
    const a = await jobFor(sender, msg);
    if (!a || a.local) return { ok: false, error: 'no job' };
    const m = await api('/api/ext/video/meta?id=' + encodeURIComponent(a.id));
    return { ok: true, meta: Object.assign({}, m, { chunk: CHUNK }) };
  },

  async videoChunk(msg, sender) {
    const a = await jobFor(sender, msg);
    if (!a || a.local) return { ok: false, error: 'no job' };
    const start = msg.index * CHUNK;
    const end = Math.min(start + CHUNK, msg.size) - 1;
    const r = await api('/api/ext/video?id=' + encodeURIComponent(a.id), { raw: true, timeoutMs: 120000, headers: { Range: `bytes=${start}-${end}` } });
    if (r.status !== 206) return { ok: false, error: 'HTTP ' + r.status + ' (cần 206 Partial Content)' };
    const buf = await r.arrayBuffer();
    if (buf.byteLength !== end - start + 1) return { ok: false, error: `độ dài sai ${buf.byteLength}` };
    await patchActive({ lastBeat: Date.now() }, a.id);
    return { ok: true, b64: b64(buf), len: buf.byteLength };
  },

  // One-time permission to click Post. Persist FIRST (conservative: a crash after this point = uncertain).
  // One-time publish grant. The local flag is persisted FIRST (a crash after it = uncertain), then the server's durable
  // conditional transition decides. A denial clears the local flag (nothing was sent).
  async authorize(msg, sender) {
    const a = await jobFor(sender, msg);
    if (!a || a.mode !== 'post') return { ok: false, reason: 'not-a-post-job' };
    const won = await locked(async () => {
      const cur = await getActive();
      if (!cur || cur.id !== a.id || cur.authorized || cur.finished) return false;
      await chrome.storage.local.set({ activeJob: Object.assign({}, cur, { authorized: true, authorizedAt: Date.now() }) });
      return true;
    });
    if (!won) return { ok: false, reason: 'already-authorized' };
    // The backend needs state=ready before it grants: tell it first (awaited, so the order is guaranteed). Nothing is
    // authorized yet, so any failure here is a plain denial.
    const ready = await sendProgress(a, { phase: 'ready', msg: 'sẵn sàng đăng' });
    if (!ready.ok || ready.unsent) {
      await patchActive({ authorized: false }, a.id);
      return { ok: false, reason: 'ready-not-confirmed' };
    }
    let r = null;
    try {
      r = await api('/api/ext/authorize', { method: 'POST', body: { id: a.id, nonce: a.nonce, claim_token: a.claim_token, body_sha256: msg.sha, creation_id: msg.creation_id,
        visibility_type: msg.visibility_type, schedule_time: msg.schedule_time == null ? null : msg.schedule_time, identity: msg.identity } });
    } catch (e) {
      // An HTTP answer (4xx, or 500 persist_failed) means NOT granted. No answer / other 5xx: it may have been granted.
      const denied = !!e.status && (e.status < 500 || e.code === 'persist_failed');
      r = { ok: false, reason: denied ? (e.code || 'http-' + e.status) : 'server-unreachable:' + e.message, unknown: !denied };
    }
    if (!r || !r.ok) {
      // unreachable = the server may have committed the grant: stay authorized (=> uncertain) and refuse the click
      if (!(r && r.unknown)) await patchActive({ authorized: false }, a.id);
      return { ok: false, reason: (r && r.reason) || 'denied' };
    }
    await log('ĐÃ CẤP QUYỀN đăng (một lần, gắn với hash nội dung)');
    return { ok: true };
  },

  async result(msg, sender) {
    const a = await jobFor(sender, msg);
    if (!a) return { ok: false };
    return finishJob(a.id, msg.result);
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const h = msg && handlers[msg.type];
  if (!h) return false; // popup messages are handled below
  h(msg, sender).then(sendResponse, (e) => { log(`handler ${msg.type}: ${e.message}`, 'ERR'); sendResponse({ ok: false, error: e.message }); });
  return true;
});

// ---------- popup messages ----------
const popup = {
  async pair(msg) {
    const code = String(msg.code || '').trim();
    if (!/^[0-9]{6}$/.test(code)) { await chrome.storage.local.set({ pairError: 'Mã gồm đúng 6 chữ số' }); return { ok: false }; }
    await chrome.storage.local.set({ pairError: '', pairing: true });
    try {
      const r = await api('/api/ext/pair', { method: 'POST', auth: false, body: { code, label: 'Chrome', ext_version: EXT_VERSION, protocol: PROTOCOL } });
      await chrome.storage.local.set({ settings: Object.assign(await getSettings(), { token: r.token, clientId: r.client_id }), pairError: '', pairing: false });
      await setConn({ state: 'ok', needReload: false, message: '' });
      await helloIfDue(true);
      pollLoop().catch((e) => console.warn('[autotok] pollLoop', e));
      return { ok: true };
    } catch (e) {
      await chrome.storage.local.set({ pairError: e.message || 'Ghép nối lỗi', pairing: false });
      return { ok: false };
    }
  },
  async unpair() {
    await chrome.storage.local.set({ settings: Object.assign(await getSettings(), { token: '', clientId: null }), conn: { state: 'unpaired', at: Date.now() } });
    return { ok: true };
  },
  async saveSettings(msg) {
    await chrome.storage.local.set({ settings: Object.assign(await getSettings(), msg.settings) });
    pollLoop().catch((e) => console.warn('[autotok] pollLoop', e));
    return { ok: true };
  },
  async selfcheck() {
    const id = 'selfcheck-' + Date.now();
    await startJob({ id, nonce: Math.random().toString(36).slice(2), mode: 'selfcheck', caption: '', visibility: 'public', schedule_time: null }, true);
    return { ok: true, id };
  },
  async clear() { // abandon the active job (e.g. after a test); does not post anything
    const a = await getActive();
    if (a) {
      if (!a.local && !a.finished) await api('/api/ext/cancel', { method: 'POST', body: { id: a.id, nonce: a.nonce, claim_token: a.claim_token, reason: 'owner-cleared' }, timeoutMs: 5000 }).catch((e) => log('cancel lỗi (xoá local tiếp): ' + e.message, 'WARN'));
      try { if (a.strategy === 'tab' && a.tabId != null) await chrome.tabs.remove(a.tabId); else if (a.windowId != null) await chrome.windows.remove(a.windowId); } catch (e) { await log('đóng cửa sổ: ' + e.message, 'WARN'); }
      await chrome.storage.local.set({ lastDoneId: a.id });
    }
    await chrome.storage.local.remove(['activeJob', 'log']);
    await log('đã xoá job đang chạy và log');
    return { ok: true };
  },
  async poll() { pollLoop().catch((e) => console.warn('[autotok] pollLoop', e)); return { ok: true }; },
};
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.popup || !popup[msg.popup]) return false;
  popup[msg.popup](msg).then(sendResponse, (e) => sendResponse({ ok: false, error: e.message }));
  return true;
});

// ---------- wake-up sources ----------
chrome.alarms.create('autotok-tick', { periodInMinutes: 0.5 });
const kick = () => pollLoop().catch((e) => console.warn('[autotok] pollLoop', e));
chrome.alarms.onAlarm.addListener(() => { recover().catch((e) => log('recover: ' + e.message, 'ERR')); kick(); });
chrome.runtime.onStartup.addListener(kick);
chrome.runtime.onInstalled.addListener(kick);

// Who closed / replaced the job tab? Log it; recover() decides after a grace period.
chrome.tabs.onRemoved.addListener(async (tabId, info) => {
  const a = await getActive();
  if (a && !a.finished && a.tabId === tabId) {
    await log(`tab ${tabId} bị đóng: isWindowClosing=${info.isWindowClosing} windowId=${info.windowId}`, 'WARN');
    await patchActive({ missingSince: Date.now() }, a.id);
  }
});
chrome.tabs.onReplaced.addListener(async (added, removed) => {
  const a = await getActive();
  if (a && !a.finished && a.tabId === removed) {
    await log(`tab ${removed} được thay bằng ${added} (prerender/discard)`, 'WARN');
    await patchActive({ tabId: added, missingSince: null, lastBeat: Date.now() }, a.id);
  }
});
log('SW khởi động');
kick();
